#!/usr/bin/env python3
"""
TIF Website Scraper
Scrapes content from Teknologiateollisuus (TIF) website and converts to markdown.
"""

import sys
import re
from urllib.parse import urlparse
from pathlib import Path

def scrape_tif_website(url: str, output_dir: str = None) -> dict:
    """
    Scrape content from a TIF website URL and prepare it for markdown conversion.

    Args:
        url: The TIF website URL to scrape
        output_dir: Optional output directory path (defaults to papers/TIF web/)

    Returns:
        dict with 'title', 'content', 'url', and 'output_path' keys
    """
    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError:
        print("Error: Required packages not installed.")
        print("Please install: pip install requests beautifulsoup4")
        sys.exit(1)

    # Fetch the page
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"Error fetching URL: {e}")
        sys.exit(1)

    # Parse HTML
    soup = BeautifulSoup(response.content, 'html.parser')

    # Extract title
    title = ""
    h1_tag = soup.find('h1')
    if h1_tag:
        title = h1_tag.get_text(strip=True)

    # Find main content area (adjust selector based on TIF website structure)
    # Common patterns: main, article, .content, #main-content
    main_content = soup.find('main') or soup.find('article') or soup.find('div', class_='content')

    if not main_content:
        print("Warning: Could not find main content area, using body")
        main_content = soup.body

    # Remove navigation, sidebar, and other non-content elements
    for element in main_content.find_all(['nav', 'aside', 'header', 'footer']):
        element.decompose()

    # Remove elements with common navigation/menu classes
    for element in main_content.find_all(class_=['navigation', 'nav', 'menu', 'sidebar', 'breadcrumb']):
        element.decompose()

    # Extract and clean content
    content_parts = []
    title_added = False

    # Look for the "Päivitetty" (updated) date
    updated_date = main_content.find('div', class_='em-block-hero__modified-date')

    # Process content elements
    for element in main_content.find_all(['h1', 'h2', 'h3', 'h4', 'p', 'ul', 'ol', 'div']):
        text = element.get_text(strip=True)

        # Stop at "Lisätiedot:"
        if text.startswith("Lisätiedot:"):
            break

        # Skip empty elements
        if not text:
            continue

        # Skip navigation/menu elements based on class or common patterns
        element_classes = element.get('class', [])
        if any(nav_class in str(element_classes).lower() for nav_class in ['nav', 'menu', 'sidebar', 'breadcrumb']):
            continue

        # Format based on element type
        if element.name == 'div':
            # Only include specific divs like the modified date
            if 'em-block-hero__modified-date' in element_classes:
                content_parts.append(f"\n{text}\n")
            continue
        elif element.name == 'h1':
            # Only add the first h1 to avoid duplication
            if not title_added and title:
                content_parts.append(f"# {text}\n")
                title_added = True
        elif element.name == 'h2':
            content_parts.append(f"\n## {text}\n")
        elif element.name == 'h3':
            content_parts.append(f"\n### {text}\n")
        elif element.name == 'h4':
            content_parts.append(f"\n#### {text}\n")
        elif element.name == 'p':
            # Skip paragraphs that are likely navigation (contain multiple links)
            links = element.find_all('a')
            if len(links) > 3:  # Likely a navigation menu
                continue
            # Fix missing spaces after periods
            text = re.sub(r'\.([A-ZÄÖÅ])', r'. \1', text)
            content_parts.append(f"\n{text}\n")
        elif element.name in ['ul', 'ol']:
            # Process list items
            list_items = element.find_all('li', recursive=False)
            for li in list_items:
                li_text = li.get_text(strip=True)
                if li_text:
                    # Clean up extra whitespace
                    li_text = ' '.join(li_text.split())
                    # Fix missing spaces after periods
                    li_text = re.sub(r'\.([A-ZÄÖÅ])', r'. \1', li_text)
                    content_parts.append(f"- {li_text}")

    content = '\n'.join(content_parts)

    # Clean up multiple newlines
    content = re.sub(r'\n{3,}', '\n\n', content)

    # Determine output path
    if output_dir is None:
        output_dir = "sources/TIF web"

    # Generate filename and folder structure from URL path
    path_parts = urlparse(url).path.strip('/').split('/')

    if path_parts and path_parts[-1]:
        # Last segment becomes the filename
        url_slug = path_parts[-1]
        filename = f"web-{url_slug}.md"

        # All segments except the last become the folder structure
        if len(path_parts) > 1:
            # Create subdirectories from URL path (excluding last segment)
            subdirs = '/'.join(path_parts[:-1])
            output_path = Path(output_dir) / subdirs / filename
        else:
            output_path = Path(output_dir) / filename
    else:
        filename = "web-scraped_content.md"
        output_path = Path(output_dir) / filename

    return {
        'title': title,
        'content': content,
        'url': url,
        'output_path': str(output_path)
    }


def create_markdown_file(scraped_data: dict, parent_doc: str = None):
    """
    Create a markdown file with proper frontmatter.

    Args:
        scraped_data: Dictionary from scrape_tif_website()
        parent_doc: Optional parent document name for 'up' field
    """
    title = scraped_data['title']
    content = scraped_data['content']
    url = scraped_data['url']
    output_path = Path(scraped_data['output_path'])

    # Create output directory if it doesn't exist
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Build frontmatter
    frontmatter_parts = [
        "---",
        "type: paper",
        f'title: "{title}"',
        f'source: "{url}"',
    ]

    if parent_doc:
        frontmatter_parts.append(f'up: "[[{parent_doc}]]"')
    else:
        frontmatter_parts.append('up:')

    frontmatter_parts.extend([
        "related:",
        "---",
    ])

    frontmatter = '\n'.join(frontmatter_parts)

    # Combine frontmatter and content
    full_content = f"{frontmatter}\n\n{content}"

    # Write to file
    output_path.write_text(full_content, encoding='utf-8')

    print(f"✅ Created paper at: {output_path}")
    return str(output_path)


def main():
    """Command-line interface"""
    if len(sys.argv) < 2:
        print("Usage: python scrape_tif_web.py <url> [output_dir] [parent_doc]")
        print("\nExample:")
        print("  python scrape_tif_web.py https://teknologiateollisuus.fi/tavoitteemme/osaava-tyovoima/")
        print("  python scrape_tif_web.py <url> 'sources/TIF web' '3000 Osaaminen'")
        sys.exit(1)

    url = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    parent_doc = sys.argv[3] if len(sys.argv) > 3 else None

    print(f"🔍 Scraping: {url}")
    scraped_data = scrape_tif_website(url, output_dir)

    print(f"📝 Creating markdown file...")
    output_path = create_markdown_file(scraped_data, parent_doc)

    print(f"\n✅ Done! Paper created at: {output_path}")


if __name__ == "__main__":
    main()

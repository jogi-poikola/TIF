---
name: tif-web-scraper
description: Scrape content from Teknologiateollisuus (TIF) website URLs and convert them to markdown papers with proper frontmatter. Use this skill when the user requests to create a paper from a TIF website URL (e.g., teknologiateollisuus.fi), extract web content for documentation, or convert TIF web pages to markdown format.
---

# TIF Web Scraper

## Overview

This skill enables scraping content from Teknologiateollisuus (Technology Industries of Finland - TIF) website and converting it into properly formatted markdown papers. The skill extracts the main content from TIF web pages, excludes sidebar elements, stops at "Lisätiedot:" sections, and generates markdown files with appropriate frontmatter including source URL tracking. The folder structure from the source URL is automatically replicated under `sources/TIF web/`.

## When to Use This Skill

Use this skill when:
- User provides a TIF website URL (teknologiateollisuus.fi) and requests a paper
- User asks to "scrape", "extract", or "convert" content from TIF website
- User wants to create documentation from TIF web content
- User mentions creating papers from TIF positions or policy pages

## How to Use

### Workflow

1. **Receive URL**: User provides a TIF website URL (e.g., `https://teknologiateollisuus.fi/tavoitteemme/osaava-tyovoima/`)

2. **Determine output location**: Default is `sources/TIF web/`, but user may specify a different location

3. **Identify parent document** (optional): Ask user if this paper should reference a parent document in the `up` field

4. **Run the scraping script**: Execute `scripts/scrape_tif_web.py` with appropriate parameters

5. **Verify output**: Check the created markdown file and show the user the path

### Script Usage

The `scrape_tif_web.py` script handles all scraping and markdown generation:

```bash
python scripts/scrape_tif_web.py <url> [output_dir] [parent_doc]
```

**Parameters:**
- `url` (required): The TIF website URL to scrape
- `output_dir` (optional): Output directory path, defaults to `sources/TIF web/`
- `parent_doc` (optional): Parent document name for the `up` field (e.g., `3000 Osaaminen`)

**Examples:**

Basic usage:
```bash
python scripts/scrape_tif_web.py https://teknologiateollisuus.fi/tavoitteemme/osaava-tyovoima/
```

With custom output directory:
```bash
python scripts/scrape_tif_web.py <url> "sources/TIF web"
```

With parent document:
```bash
python scripts/scrape_tif_web.py <url> "sources/TIF web" "3000 Osaaminen"
```

### Output Format

The script generates markdown files with this frontmatter structure:

```yaml
---
type: paper
title: "Page Title from Website"
source: "https://teknologiateollisuus.fi/..."
up: "[[Parent Document]]"  # Optional
related:
---
```

Followed by the cleaned main content in markdown format.

### Content Extraction

The script:
- Extracts main content area (excluding sidebars and navigation)
- Converts HTML headings to markdown headings (h1-h4 → #, ##, ###, ####)
- Converts paragraphs and lists to markdown format
- Stops extraction when encountering "Lisätiedot:" (Additional information)
- Removes excessive whitespace and cleans formatting

### Folder Structure

The script automatically replicates the URL path structure:
- URL: `https://teknologiateollisuus.fi/tavoitteemme/innovaatiot/`
- Creates: `sources/TIF web/tavoitteemme/web-innovaatiot.md`

This preserves the organizational structure from the TIF website in your local file system.

### Dependencies

The script requires:
- `requests` - for HTTP requests
- `beautifulsoup4` - for HTML parsing

If not installed, run:
```bash
pip install requests beautifulsoup4
```

The script will display a helpful error message if these packages are missing.

## Example Usage Scenarios

**Scenario 1: Basic paper creation**
```
User: "Create a paper from https://teknologiateollisuus.fi/tavoitteemme/osaava-tyovoima/"

Actions:
1. Run: python scripts/scrape_tif_web.py <url>
2. Verify the created file in sources/TIF web/
3. Show user the output path
```

**Scenario 2: With parent document**
```
User: "Create a paper from <url> and link it to the '3000 Osaaminen' position"

Actions:
1. Run: python scripts/scrape_tif_web.py <url> "sources/TIF web" "3000 Osaaminen"
2. Verify the frontmatter includes: up: "[[3000 Osaaminen]]"
3. Show user the output
```

**Scenario 3: Batch processing**
```
User: "Create papers from these three URLs: <url1>, <url2>, <url3>"

Actions:
1. Run the script three times with each URL
2. Report all created file paths
3. Summarize the batch operation
```

## Troubleshooting

**If scraping fails:**
1. Verify the URL is accessible and from teknologiateollisuus.fi
2. Check network connectivity
3. Examine the HTML structure if the selectors don't match

**If content extraction is incomplete:**
1. The script may need adjustment for specific page layouts
2. Check if "Lisätiedot:" appears early in the content
3. Verify the main content selector matches the page structure

**If dependencies are missing:**
1. The script will display installation instructions
2. Run: `pip install requests beautifulsoup4`
